-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: localhost    Database: abm_cinemas
-- ------------------------------------------------------
-- Server version	8.0.41
create database abm_cinemas;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bookings`
--

DROP TABLE IF EXISTS `bookings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bookings` (
  `booking_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `seat_number` varchar(10) DEFAULT NULL,
  `movie_id` int DEFAULT NULL,
  `booking_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `booking_date` date NOT NULL DEFAULT (curdate()),
  PRIMARY KEY (`booking_id`),
  KEY `user_id` (`user_id`),
  KEY `movie_id` (`movie_id`),
  KEY `seat_number` (`seat_number`),
  CONSTRAINT `bookings_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `bookings_ibfk_2` FOREIGN KEY (`movie_id`) REFERENCES `movies` (`movie_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `bookings_ibfk_3` FOREIGN KEY (`seat_number`) REFERENCES `seats` (`seat_number`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bookings`
--

LOCK TABLES `bookings` WRITE;
/*!40000 ALTER TABLE `bookings` DISABLE KEYS */;
INSERT INTO `bookings` VALUES (9,13,'ABM16',3,'2025-05-13 21:52:30','2025-05-13'),(13,13,'ABM1',1,'2025-05-15 03:18:40','2025-05-14');
/*!40000 ALTER TABLE `bookings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `movies`
--

DROP TABLE IF EXISTS `movies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `movies` (
  `movie_id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `duration` int DEFAULT NULL,
  `genre` varchar(50) DEFAULT NULL,
  `industry` varchar(100) DEFAULT NULL,
  `release_date` date DEFAULT NULL,
  `show_time` time DEFAULT NULL,
  `show_date` date DEFAULT NULL,
  PRIMARY KEY (`movie_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `movies`
--

LOCK TABLES `movies` WRITE;
/*!40000 ALTER TABLE `movies` DISABLE KEYS */;
INSERT INTO `movies` VALUES (1,'Titanic',195,'Romance/Drama','Hollywood','1997-12-19','12:30:00','2025-05-17'),(2,'Animal',180,'Action/Drama','Bollywood','2023-12-01','15:00:00','2025-05-20'),(3,'Drishyam',150,'Thriller','Bollywood','2015-07-31','18:45:00','2025-05-23'),(4,'Crew',135,'Comedy/Drama','Bollywood','2024-03-29','14:15:00','2025-05-18'),(5,'Jawani Phir Nahi Aani',170,'Comedy','Lollywood','2015-09-25','16:45:00','2025-05-22'),(6,'Parwaaz Hai Junoon',130,'Drama/War','Lollywood','2018-08-22','13:30:00','2025-05-24'),(7,'Raazi',140,'Thriller/Drama','Bollywood','2018-05-11','17:15:00','2025-05-27'),(10,'Chota bheem aur kirmada',60,'Comedy/adventure','Bollywood','2018-09-03','15:30:00','2025-06-01');
/*!40000 ALTER TABLE `movies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `seats`
--

DROP TABLE IF EXISTS `seats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `seats` (
  `seat_number` varchar(10) DEFAULT NULL,
  `price` int DEFAULT NULL,
  UNIQUE KEY `unique_seat_number` (`seat_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `seats`
--

LOCK TABLES `seats` WRITE;
/*!40000 ALTER TABLE `seats` DISABLE KEYS */;
INSERT INTO `seats` VALUES ('ABM1',1000),('ABM2',1000),('ABM3',1000),('ABM4',1000),('ABM5',1000),('ABM6',1000),('ABM7',1000),('ABM8',1000),('ABM9',1000),('ABM10',1000),('ABM11',800),('ABM12',800),('ABM13',800),('ABM14',800),('ABM15',800),('ABM16',800),('ABM17',800),('ABM18',800),('ABM19',800),('ABM20',800),('ABM21',800),('ABM22',800),('ABM23',800),('ABM24',800),('ABM25',800),('ABM26',800),('ABM27',800),('ABM28',800),('ABM29',800),('ABM30',800),('ABM31',800),('ABM32',800),('ABM33',800),('ABM34',800),('ABM35',800),('ABM36',800),('ABM37',800),('ABM38',800),('ABM39',800),('ABM40',800),('ABM41',800),('ABM42',800),('ABM43',800),('ABM44',800),('ABM45',800),('ABM46',800),('ABM47',800),('ABM48',800),('ABM49',800),('ABM50',800),('ABM51',600),('ABM52',600),('ABM53',600),('ABM54',600),('ABM55',600),('ABM56',600),('ABM57',600),('ABM58',600),('ABM59',600),('ABM60',600);
/*!40000 ALTER TABLE `seats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `user_id` int NOT NULL AUTO_INCREMENT,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `phone_number` decimal(10,0) DEFAULT NULL,
  `is_admin` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Marzia','Rizvi','marzia.rizvi@example.com','pass1211',3001234567,1),(2,'Amna','Memon','amna.memon@example.com','pass1222',3007654321,1),(3,'Bushra','Panhwer','bushra.panhwer@example.com','pass1233',3009876543,1),(4,'Marzia','Rizvi','david.admin@example.com','pass1244',3005432109,1),(5,'marzia','syeda','marziaseda@gmail.com','rizvi217',9087654321,0),(6,'Marzia','Syeda','marziasyeda@gmail.com','rizvi217',987654321,0),(7,'Marzia','Syeda','marziasyeda217@gmail.com','rizvi217',1234567890,0),(8,'Hassan','Raza','hassan@gmail.com','hello',3214567890,0),(9,'abbas','raza','hassan1@gmail.com','hello',3009315430,0),(10,'bushra','panhwer','bushra@gmail.com','bushra',3008976543,0),(11,'hi','jvkh','marzia@gmail.com','hello',3458989712,0),(12,'bushra','p','dfff@gmail.com','hello',3124567890,0),(13,'Bushra','panhwer','bushra1@gmail.com','hello',3214567890,0),(14,'Ali Raza','Rizvi','aliraza237@gmail.com','hello',3021456723,0),(15,'Waqar','Ahmed','waqarahmed@gmail.com','hello',3009315430,0);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-05-17  6:23:39
