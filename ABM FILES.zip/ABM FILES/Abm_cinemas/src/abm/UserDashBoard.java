package abm;

import javax.swing.*;
import java.awt.*;

public class UserDashBoard extends JFrame {
    private Image backgroundImage;
    private JButton viewMovies, viewYourBooking, bookATicket, cancelBooking, logout;
    private int userId;

    public UserDashBoard(int userId) {
        this.userId = userId;

        setTitle("User Dashboard");
        setSize(1300, 738);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(true);

        // Load background image
        try {
            backgroundImage = new ImageIcon(getClass().getResource("/images/background.png")).getImage();
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Custom panel with background image
        JPanel contentPane = new JPanel(new GridBagLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (backgroundImage != null) {
                    g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
                }
            }
        };
        contentPane.setOpaque(false);
        setContentPane(contentPane);
        setLayout(null);

        // Title Label
        JLabel title = new JLabel("ABM CINEMAS", SwingConstants.CENTER);
        title.setFont(new Font("Ravie", Font.BOLD, 100));
        title.setForeground(Color.YELLOW);
        title.setBounds(0, 50, 1300, 150);
        contentPane.add(title);

        // View Movie Showtimes Button
        viewMovies = new JButton("View Movie ShowTimes");
        viewMovies.setFont(new Font("Segoe UI", Font.BOLD, 45));
        viewMovies.setForeground(Color.RED);
        viewMovies.setBackground(Color.BLACK);
        viewMovies.setBounds(390, 200, 560, 60);
        contentPane.add(viewMovies);

        // Book Ticket Button
        bookATicket = new JButton("Book Ticket");
        bookATicket.setFont(new Font("Segoe UI", Font.BOLD, 45));
        bookATicket.setForeground(Color.RED);
        bookATicket.setBackground(Color.BLACK);
        bookATicket.setBounds(390, 270, 560, 60);
        contentPane.add(bookATicket);

        // View Your Booking Button
        viewYourBooking = new JButton("View Your Booking");
        viewYourBooking.setFont(new Font("Segoe UI", Font.BOLD, 45));
        viewYourBooking.setForeground(Color.RED);
        viewYourBooking.setBackground(Color.BLACK);
        viewYourBooking.setBounds(390, 350, 560, 60);
        contentPane.add(viewYourBooking);

        // Cancel Booking Button
        cancelBooking = new JButton("Cancel Booking");
        cancelBooking.setFont(new Font("Segoe UI", Font.BOLD, 45));
        cancelBooking.setForeground(Color.RED);
        cancelBooking.setBackground(Color.BLACK);
        cancelBooking.setBounds(390, 430, 560, 60);
        contentPane.add(cancelBooking);

        // Logout Button
        logout = new JButton("Logout");
        logout.setFont(new Font("Segoe UI", Font.BOLD, 45));
        logout.setForeground(Color.RED);
        logout.setBackground(Color.BLACK);
        logout.setBounds(390, 510, 560, 60);
        contentPane.add(logout);

        // Action Listeners
        logout.addActionListener(e -> {
            dispose();
            new Welcome().setVisible(true);
        });

        viewMovies.addActionListener(e -> {
            dispose();
            new Movies(userId).setVisible(true);         });

        bookATicket.addActionListener(e -> {
            dispose();
            new BookaTicket(userId).setVisible(true);
        });

        viewYourBooking.addActionListener(e -> {
            dispose();
           new ShowBookings(userId).setVisible(true); 
        });

        cancelBooking.addActionListener(e -> {
            dispose();
           new CancelBooking(userId).setVisible(true); 
        });

        setVisible(true);
    }

    public static void main(String[] args) {
     new UserDashBoard(1).setVisible(true);
    }
}




