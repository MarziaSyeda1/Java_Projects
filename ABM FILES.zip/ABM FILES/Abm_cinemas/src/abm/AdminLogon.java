package abm;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class AdminLogon extends JFrame {
    private JLabel adminIdLabel, passwordLabel;
    private Image backgroundImage;
    private JTextField adminField;
    private JPasswordField passwordField;
    private JButton loginButton, backButton;

    public AdminLogon() {
        setTitle("Admin Login");
        setSize(1300, 738);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(true);

        try {
            backgroundImage = new ImageIcon(getClass().getResource("/images/background.png")).getImage();
        } catch (Exception e) {
            e.printStackTrace();
        }

        JPanel contentPane = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (backgroundImage != null) {
                    g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
                }
            }
        };
        contentPane.setLayout(null);
        setContentPane(contentPane);

        JLabel title = new JLabel("ABM CINEMAS", SwingConstants.CENTER);
        title.setFont(new Font("Ravie", Font.BOLD, 100));
        title.setForeground(Color.YELLOW);
        title.setBounds(0, 30, 1300, 150);
        contentPane.add(title);

        adminIdLabel = new JLabel("Admin ID:");
        adminIdLabel.setFont(new Font("Segoe UI", Font.BOLD, 35));
        adminIdLabel.setForeground(Color.YELLOW);
        adminIdLabel.setBackground(Color.BLACK);
        adminIdLabel.setOpaque(true);
        adminIdLabel.setBounds(350, 250, 200, 50);
        contentPane.add(adminIdLabel);

        adminField = new JTextField();
        adminField.setFont(new Font("Segoe UI", Font.PLAIN, 30));
        adminField.setBounds(600, 250, 300, 50);
        contentPane.add(adminField);

        passwordLabel = new JLabel("Password:");
        passwordLabel.setFont(new Font("Segoe UI", Font.BOLD, 35));
        passwordLabel.setForeground(Color.YELLOW);
        passwordLabel.setBackground(Color.BLACK);
        passwordLabel.setOpaque(true);
        passwordLabel.setBounds(350, 320, 200, 50);
        contentPane.add(passwordLabel);

        passwordField = new JPasswordField();
        passwordField.setFont(new Font("Segoe UI", Font.PLAIN, 30));
        passwordField.setBounds(600, 320, 300, 50);
        contentPane.add(passwordField);

        backButton = new JButton("Back");
        backButton.setFont(new Font("Segoe UI", Font.BOLD, 30));
        backButton.setBackground(Color.BLACK);
        backButton.setForeground(Color.RED);
        backButton.setBounds(350, 430, 180, 60);
        contentPane.add(backButton);

        loginButton = new JButton("Log-in");
        loginButton.setFont(new Font("Segoe UI", Font.BOLD, 30));
        loginButton.setBackground(Color.BLACK);
        loginButton.setForeground(Color.RED);
        loginButton.setBounds(720, 430, 180, 60);
        contentPane.add(loginButton);

        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String adminId = adminField.getText().trim();
                String password = new String(passwordField.getPassword()).trim();

                try {
                    Connection conn = DBConnection.getConnection();
                    String query = "Select * from users WHERE user_id = ? AND password = ? AND is_admin = true";
                    PreparedStatement stmt = conn.prepareStatement(query);
                    stmt.setString(1, adminId);
                    stmt.setString(2, password);

                    ResultSet rs = stmt.executeQuery();

                    if (rs.next()) {
                        String name = rs.getString("first_name");
                        JOptionPane.showMessageDialog(null, "Welcome Admin " + name + "!");
                        dispose();
                        new AdminDashboard().setVisible(true);
                    } else {
                        JOptionPane.showMessageDialog(null, "Invalid Admin ID, Password, or not an Admin.");
                    }

                    rs.close();
                    stmt.close();
                    conn.close();
                } catch (Exception ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(null, "Database Error: " + ex.getMessage());
                }
            }
        });

        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                new Welcome().setVisible(true);
            }
        });
    }

    public static void main(String[] args) {
    new AdminLogon().setVisible(true);
    }
}


