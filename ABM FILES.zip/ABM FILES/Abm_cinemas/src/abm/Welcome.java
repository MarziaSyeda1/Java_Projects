package abm;

import javax.swing.*;
import java.awt.*;

public class Welcome extends JFrame {
    private Image backgroundImage;

    public Welcome() {
        setTitle("Welcome");
        setSize(1300, 738);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(true);

        try {
            backgroundImage = new ImageIcon(getClass().getResource("/images/background.png")).getImage();
        } catch (Exception e) {
            e.printStackTrace();
        }

        JPanel contentPane = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (backgroundImage != null) {
                    g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
                }
            }
        };
        contentPane.setLayout(null);
        setContentPane(contentPane);

        JLabel title = new JLabel("ABM CINEMAS", SwingConstants.CENTER);
        title.setFont(new Font("Ravie", Font.BOLD, 100));
        title.setForeground(Color.YELLOW);
        title.setOpaque(false);
        title.setBounds(0, 20, 1300, 150);
        contentPane.add(title);

        JLabel slogan = new JLabel("Drama? Only On Screens!", SwingConstants.CENTER);
        slogan.setFont(new Font("High Tower Text", Font.BOLD, 35));
        slogan.setForeground(Color.YELLOW);
        slogan.setBackground(Color.BLACK);
        slogan.setOpaque(true);
        slogan.setBounds(400, 170, 500, 50);
        contentPane.add(slogan);

        JLabel question = new JLabel("Are you an Admin or a User?", SwingConstants.CENTER);
        question.setFont(new Font("High Tower Text", Font.BOLD, 40));
        question.setForeground(Color.CYAN);
        question.setBackground(Color.BLACK);
        question.setOpaque(true);
        question.setBounds(380, 330, 550, 60);
        contentPane.add(question);

        JButton adminButton = new JButton("Admin");
        adminButton.setFont(new Font("Segoe UI", Font.BOLD, 40));
        adminButton.setForeground(Color.RED);
        adminButton.setBackground(Color.BLACK);
        adminButton.setBounds(400, 440, 180, 100);
        contentPane.add(adminButton);

        JButton userButton = new JButton("User");
        userButton.setFont(new Font("Segoe UI", Font.BOLD, 40));
        userButton.setBackground(Color.BLACK);
        userButton.setForeground(Color.RED);
        userButton.setBounds(720, 440, 180, 100);
        contentPane.add(userButton);

        adminButton.addActionListener(e -> {
            dispose();
         new AdminLogon().setVisible(true);
        });

        userButton.addActionListener(e -> {
            dispose();
            new UserChoices().setVisible(true);
        });
    }

    public static void main(String[] args) {
     new Welcome().setVisible(true);
    }
}
