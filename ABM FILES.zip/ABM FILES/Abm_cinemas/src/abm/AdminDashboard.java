package abm;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class AdminDashboard extends JFrame {
	  private Image backgroundImage;
	private JButton ViewRegisteredUsers, addMovies, deletemovies, ViewBookings;
	private JButton CancelBookings, Logout;
	public AdminDashboard() {
		 setTitle("Admin Dashboard");
	        setSize(1300, 738);
	        setDefaultCloseOperation(EXIT_ON_CLOSE);
	        setLocationRelativeTo(null);
	        setResizable(true);

	        try {
	            backgroundImage = new ImageIcon(getClass().getResource("/images/background.png")).getImage();
	        } catch (Exception e) {
	            e.printStackTrace();
	        }

	        JPanel contentPane = new JPanel(new GridBagLayout()) {
	            @Override
	            protected void paintComponent(Graphics g) {
	                super.paintComponent(g);
	                if (backgroundImage != null) {
	                    g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
	                }
	            }
	        };
	        contentPane.setOpaque(false);
	        setContentPane(contentPane);

	        setLayout(null);
	        JLabel title = new JLabel("ABM CINEMAS", SwingConstants.CENTER);
	        title.setFont(new Font("Ravie", Font.BOLD, 100));
	        title.setForeground(Color.YELLOW);
	        title.setBounds(0, 50, 1300, 150);
	        contentPane.add(title);
	        
	        ViewRegisteredUsers= new JButton(" View Registered Users ");
	        ViewRegisteredUsers.setFont(new Font("Segoe UI", Font.BOLD, 45));
	        ViewRegisteredUsers.setForeground(Color.RED);
	        ViewRegisteredUsers.setBounds(390, 180, 560, 60);
	        ViewRegisteredUsers.setBorder(null);
	        ViewRegisteredUsers.setBackground(Color.BLACK);
	       contentPane.add(ViewRegisteredUsers);
	        
	       addMovies= new JButton(" Add Movies ");
	       addMovies.setFont(new Font("Segoe UI", Font.BOLD, 45));
	       addMovies.setForeground(Color.RED);
	       addMovies.setBounds(390, 260, 560, 60);
	       addMovies.setBorder(null);
	       addMovies.setBackground(Color.BLACK);
	       contentPane.add(addMovies);
	        
	     
	       
	       deletemovies = new JButton(" Delete Movies ");
	       deletemovies.setFont(new Font("Segoe UI", Font.BOLD, 45));
	       deletemovies.setForeground(Color.RED);
	       deletemovies.setBounds(390, 340, 560, 60);
	       deletemovies.setBorder(null);
	       deletemovies.setBackground(Color.BLACK);
	       contentPane.add(deletemovies);
	       
	       ViewBookings = new JButton(" View all Bookings ");
	       ViewBookings .setFont(new Font("Segoe UI", Font.BOLD, 45));
	       ViewBookings .setForeground(Color.RED);
	       ViewBookings .setBounds(390, 420, 560, 60);
	       ViewBookings .setBorder(null);
	       ViewBookings .setBackground(Color.BLACK);
	       contentPane.add( ViewBookings );
	       
	       CancelBookings = new JButton("Cancel Bookings"); 
	       CancelBookings .setFont(new Font("Segoe UI", Font.BOLD, 45));
	       CancelBookings .setForeground(Color.RED);
	       CancelBookings .setBounds(390, 500, 560, 60);
	       CancelBookings .setBorder(null);
	       CancelBookings.setBackground(Color.BLACK);
	       contentPane.add(CancelBookings);
	       
	       
	       Logout = new JButton("Logout"); 
	       Logout .setFont(new Font("Segoe UI", Font.BOLD, 45));
	       Logout .setForeground(Color.RED);
	       Logout .setBounds(390, 580, 560, 60);
	       Logout .setBorder(null);
	       Logout.setBackground(Color.BLACK);
	       contentPane.add(Logout);
	       
	       Logout.addActionListener(e -> {
	            dispose();
	            new Welcome().setVisible(true);
	        } 
	       );
	
	       ViewRegisteredUsers.addActionListener(e -> {
	    	    dispose();
	    	    new ViewRegisteredUsers().setVisible(true);});
	      CancelBookings.addActionListener(e -> {
	    	    dispose();
	    	    new AdminCancelBooking().setVisible(true);});
	      
	      ViewBookings.addActionListener(e -> {
	    	    dispose();
	    	    new AdminViewBookings().setVisible(true);});
	      
	      addMovies.addActionListener(e -> {
	    	    dispose();
	    	    new AddMovies().setVisible(true);});  
	      deletemovies.addActionListener(e -> {
	    	    dispose();
	    	    new DeleteMovie().setVisible(true);});  
	}
	
	
public static void main(String[] v) {
	  new AdminDashboard().setVisible(true);;
}
}
