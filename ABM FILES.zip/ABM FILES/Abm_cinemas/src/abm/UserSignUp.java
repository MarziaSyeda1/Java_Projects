package abm;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridBagLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import javax.swing.*;
import javax.swing.*;
public class UserSignUp extends JFrame {
    private JLabel firstName,lastName,email,password,phone;
    private JTextField firstNameField,lastNameField,emailField,passwordField,phoneField;
    private JButton signUp,back;
    private Image backgroundImage;
    public UserSignUp() {
        setTitle("User Choices");
        setSize(1300, 738);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(true);

        try {
            backgroundImage = new ImageIcon(getClass().getResource("/images/background.png")).getImage();
        } catch (Exception e) {
            e.printStackTrace();
        }

        JPanel contentPane = new JPanel(new GridBagLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (backgroundImage != null) {
                    g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
                }
            }
        };
        contentPane.setOpaque(false);
        setContentPane(contentPane);

        setLayout(null);
        JLabel title = new JLabel("ABM CINEMAS", SwingConstants.CENTER);
        title.setFont(new Font("Ravie", Font.BOLD, 100));
        title.setForeground(Color.YELLOW);
        title.setBounds(0, 50, 1300, 150);
        contentPane.add(title);
        
        
        firstName = new JLabel("First Name:");
        firstName.setFont(new Font("Segoe UI", Font.BOLD, 30));
        firstName.setForeground(Color.CYAN);
        firstName.setBackground(Color.BLACK);
        firstName.setOpaque(true);
        firstName.setBounds(400,200, 175, 40);
        contentPane.add(firstName);

        lastName = new JLabel("Last Name:");
        lastName.setFont(new Font("Segoe UI", Font.BOLD, 30));
        lastName.setForeground(Color.CYAN);
        lastName.setBackground(Color.BLACK);
        lastName.setOpaque(true);
        lastName.setBounds(400,270, 175, 40);
        contentPane.add(lastName);

        email = new JLabel("Email:");
        email.setFont(new Font("Segoe UI", Font.BOLD, 30));
        email.setForeground(Color.CYAN);
        email.setBackground(Color.BLACK);
        email.setOpaque(true);
        email.setBounds(400,340, 100, 40);
        contentPane.add(email);

        phone = new JLabel("Phone:");
        phone.setFont(new Font("Segoe UI", Font.BOLD, 30));
        phone.setForeground(Color.CYAN);
        phone.setBackground(Color.BLACK);
        phone.setOpaque(true);
        phone.setBounds(400,410, 100, 40);
        contentPane.add(phone);

        password = new JLabel("Set Password:");
        password.setFont(new Font("Segoe UI", Font.BOLD, 30));
        password.setForeground(Color.CYAN);
        password.setBackground(Color.BLACK);
        password.setOpaque(true);
        password.setBounds(400, 480, 200, 40);
        contentPane.add(password);
   
        firstNameField = new JTextField();
        firstNameField.setFont(new Font("Segoe UI", Font.PLAIN, 25));
        firstNameField.setBounds(620, 200, 300, 40); // next to "First Name:"
        contentPane.add(firstNameField);

        lastNameField = new JTextField();
        lastNameField.setFont(new Font("Segoe UI", Font.PLAIN, 25));
        lastNameField.setBounds(620, 270, 300, 40); 
        contentPane.add(lastNameField);

     
        emailField = new JTextField();
        emailField.setFont(new Font("Segoe UI", Font.PLAIN, 25));
        emailField.setBounds(620, 340, 300, 40);
        contentPane.add(emailField);

        phoneField = new JTextField();
        phoneField.setFont(new Font("Segoe UI", Font.PLAIN, 25));
        phoneField.setBounds(620, 410, 300, 40);
        contentPane.add(phoneField);

        passwordField = new JPasswordField();
        passwordField.setFont(new Font("Segoe UI", Font.PLAIN, 25));
        passwordField.setBounds(620, 480, 300, 40);
        contentPane.add(passwordField);
        
        signUp = new JButton("SignUp");
        signUp.setFont(new Font("Segoe UI", Font.BOLD, 35));
        signUp.setForeground(Color.RED);
        signUp.setBounds(600, 550, 180, 90);
        contentPane.add(signUp);
        
        back = new JButton("Back");
        back.setFont(new Font("Segoe UI", Font.BOLD, 30));
        back.setForeground(Color.YELLOW);
        back.setBackground(Color.BLACK);
        back.setBounds(100, 500, 100, 80);
        contentPane.add(back);
        
        back.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	dispose();
            	new UserChoices().setVisible(true);}
            }    );
        
        signUp.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String firstName = firstNameField.getText().trim();
                String lastName = lastNameField.getText().trim();
                String email = emailField.getText().trim();
                String password = new String(((JPasswordField) passwordField).getPassword()).trim(); 
                String phone = phoneField.getText().trim();

             
                if (firstName.isEmpty() || lastName.isEmpty() || email.isEmpty() || password.isEmpty() || phone.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "All fields must be filled!");
                    return;
                }

            
                if (!email.contains("@") || !email.contains(".")) {
                    JOptionPane.showMessageDialog(null, "Please enter a valid email address!");
                    return;
                }

        
                if (phone.length() < 11 || !phone.matches("\\d+")) {
                    JOptionPane.showMessageDialog(null, "Phone number must be at least 11 digits and numeric!");
                    return;
                }

       
                try {
                    Connection conn = DBConnection.getConnection();
                    String checkQuery = "SELECT * FROM users WHERE email = ?";
                    PreparedStatement checkStmt = conn.prepareStatement(checkQuery);
                    checkStmt.setString(1, email);
                    ResultSet rs = checkStmt.executeQuery();
                    if (rs.next()) {
                        JOptionPane.showMessageDialog(null, "Email already registered!");
                        rs.close();
                        checkStmt.close();
                        conn.close();
                        return;
                    }
                    rs.close();
                    checkStmt.close();

                    String insertQuery = "INSERT into users (first_name, last_name, email, phone_number, password) VALUES (?, ?, ?, ?, ?)";
                    PreparedStatement insertStmt = conn.prepareStatement(insertQuery, Statement.RETURN_GENERATED_KEYS);
                    insertStmt.setString(1, firstName);
                    insertStmt.setString(2, lastName);
                    insertStmt.setString(3, email);
                    insertStmt.setString(4, phone);
                    insertStmt.setString(5, password); 

                    int rows = insertStmt.executeUpdate();
                    if (rows > 0) {
                        ResultSet keys = insertStmt.getGeneratedKeys();
                        if (keys.next()) {
                            int userId = keys.getInt(1);
                            JOptionPane.showMessageDialog(null, "Sign up successful! Your user ID is: " + userId);
                        }
                        keys.close();

                        firstNameField.setText("");
                        lastNameField.setText("");
                        emailField.setText("");
                        passwordField.setText("");
                        phoneField.setText("");

                        dispose(); 
                        SwingUtilities.invokeLater(() -> new UserLogin().setVisible(true));
                    } else {
                        JOptionPane.showMessageDialog(null, "Signup failed. Please try again.");
                    }

                    insertStmt.close();
                    conn.close();

                } catch (Exception ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(null, "Database Error: " + ex.getMessage());
                    SwingUtilities.invokeLater(() -> new UserSignUp().setVisible(true));
                }
            }
        }); 
	
        }

 
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new UserSignUp().setVisible(true));
    }
        }
