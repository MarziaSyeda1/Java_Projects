package abm;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.sql.*;

public class AdminViewBookings extends JFrame {
    private JTable table;
    private JButton back;
    private Image backgroundImage;

    public AdminViewBookings() {
        setTitle("View All Bookings - Admin");
        setSize(1300, 738);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(true);

        try {
            backgroundImage = new ImageIcon(getClass().getResource("/images/background.png")).getImage();
        } catch (Exception e) {
            e.printStackTrace();
        }

        JPanel contentPane = new JPanel() {
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (backgroundImage != null) {
                    g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
                }
            }
        };
        contentPane.setLayout(null);
        setContentPane(contentPane);

        JLabel titleLabel = new JLabel("ABM CINEMAS", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Ravie", Font.BOLD, 80));
        titleLabel.setForeground(Color.YELLOW);
        titleLabel.setBounds(0, 25, 1300, 100);
        contentPane.add(titleLabel);

        String[] columns = {"Booking ID", "User ID", "title", "Seat", "Show Time", "Show Date"};
        DefaultTableModel model = new DefaultTableModel(columns, 0);

        try (Connection conn = DBConnection.getConnection()) {
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("select b.booking_id,b.user_id,m.title,b.seat_number, m.show_time, m.show_date FROM bookings b join movies m using(movie_id)");

            while (rs.next()) {
                model.addRow(new Object[] {
                    rs.getInt("booking_id"),
                    rs.getInt("user_id"),
                    rs.getString("title"),
                    rs.getString("seat_number"),
                    rs.getString("show_time"),
                    rs.getString("show_date")
                });
            }

            rs.close();
            stmt.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error loading bookings: " + e.getMessage());
        }

        table = new JTable(model);
        table.setFont(new Font("Verdana", Font.BOLD, 15));
        table.setRowHeight(60);
        table.setForeground(Color.RED);
        table.setBackground(Color.BLACK);

        JTableHeader header = table.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 18));
        header.setForeground(Color.YELLOW);
        header.setBackground(Color.BLACK);

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(100, 150, 1100, 500);
        scrollPane.setOpaque(false);
        scrollPane.getViewport().setOpaque(false);
        contentPane.add(scrollPane);

        back = new JButton("Back");
        back.setFont(new Font("Segoe UI", Font.BOLD, 30));
        back.setForeground(Color.YELLOW);
        back.setBackground(Color.BLACK);
        back.setBounds(30, 40, 120, 50);
        contentPane.add(back);

        back.addActionListener(e -> {
            dispose();
            new AdminDashboard().setVisible(true); 
        });

        setVisible(true);
    }

    public static void main(String[] args) {
       new AdminViewBookings().setVisible(true);;
    }
}

