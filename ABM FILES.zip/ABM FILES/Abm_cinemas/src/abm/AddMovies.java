package abm;

import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class AddMovies extends JFrame {
    private JTextField titleField, durationField, genreField, industryField, releaseDateField, showTimeField, showDateField;
    private JButton addButton, backButton;
    private Image backgroundImage;


    public AddMovies() {
    

        setTitle("Add New Movie");
        setSize(1300, 738);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(true);

        try {
            backgroundImage = new ImageIcon(getClass().getResource("/images/background.png")).getImage();
        } catch (Exception e) {
            e.printStackTrace();
        }

        JPanel contentPane = new JPanel() {
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (backgroundImage != null) {
                    g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
                }
            }
        };
        contentPane.setLayout(null);
        setContentPane(contentPane);

        JLabel header = new JLabel("ABM CINEMAS", SwingConstants.CENTER);
        header.setFont(new Font("Ravie", Font.BOLD, 80));
        header.setForeground(Color.YELLOW);
        header.setBounds(0, 40, 1300, 110);
        contentPane.add(header);

        JLabel titleLabel = new JLabel("Title:");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 22));
        titleLabel.setForeground(Color.YELLOW);
        titleLabel.setBackground(Color.BLACK);
        titleLabel.setOpaque(true);
        titleLabel.setBounds(200, 150, 250, 30);
        contentPane.add(titleLabel);

        titleField = new JTextField();
        titleField.setFont(new Font("Segoe UI", Font.PLAIN, 20));
        titleField.setBounds(550, 150, 400, 35);
        contentPane.add(titleField);

        JLabel durationLabel = new JLabel("Duration (minutes):");
        durationLabel.setFont(new Font("Segoe UI", Font.BOLD, 22));
        durationLabel.setForeground(Color.YELLOW);
        durationLabel.setBackground(Color.BLACK);
        durationLabel.setOpaque(true);
        durationLabel.setBounds(200, 200, 250, 30);
        contentPane.add(durationLabel);

        durationField = new JTextField();
        durationField.setFont(new Font("Segoe UI", Font.PLAIN, 20));
        durationField.setBounds(550, 200, 400, 35);
        contentPane.add(durationField);

        JLabel genreLabel = new JLabel("Genre:");
        genreLabel.setFont(new Font("Segoe UI", Font.BOLD, 22));
        genreLabel.setForeground(Color.YELLOW);
        genreLabel.setBackground(Color.BLACK);
        genreLabel.setOpaque(true);
        genreLabel.setBounds(200, 250, 250, 30);
        contentPane.add(genreLabel);

        genreField = new JTextField();
        genreField.setFont(new Font("Segoe UI", Font.PLAIN, 20));
        genreField.setBounds(550, 250, 400, 35);
        contentPane.add(genreField);

        JLabel industryLabel = new JLabel("Industry:");
        industryLabel.setFont(new Font("Segoe UI", Font.BOLD, 22));
        industryLabel.setForeground(Color.YELLOW);
        industryLabel.setBackground(Color.BLACK);
        industryLabel.setOpaque(true);
        industryLabel.setBounds(200, 300, 250, 30);
        contentPane.add(industryLabel);

        industryField = new JTextField();
        industryField.setFont(new Font("Segoe UI", Font.PLAIN, 20));
        industryField.setBounds(550, 300, 400, 35);
        contentPane.add(industryField);

        JLabel releaseDateLabel = new JLabel("Release Date (YYYY-MM-DD):");
        releaseDateLabel.setFont(new Font("Segoe UI", Font.BOLD, 22));
        releaseDateLabel.setForeground(Color.YELLOW);
        releaseDateLabel.setBackground(Color.BLACK);
        releaseDateLabel.setOpaque(true);
        releaseDateLabel.setBounds(200, 350, 330, 30);
        contentPane.add(releaseDateLabel);

        releaseDateField = new JTextField();
        releaseDateField.setFont(new Font("Segoe UI", Font.PLAIN, 20));
        releaseDateField.setBounds(550, 350, 400, 35);
        contentPane.add(releaseDateField);

        JLabel showTimeLabel = new JLabel("Show Time (HH:MM:SS):");
        showTimeLabel.setFont(new Font("Segoe UI", Font.BOLD, 22));
        showTimeLabel.setForeground(Color.YELLOW);
        showTimeLabel.setBackground(Color.BLACK);
        showTimeLabel.setOpaque(true);
        showTimeLabel.setBounds(200, 400, 300, 30);
        contentPane.add(showTimeLabel);

        showTimeField = new JTextField();
        showTimeField.setFont(new Font("Segoe UI", Font.PLAIN, 20));
        showTimeField.setBounds(550, 400, 400, 35);
        contentPane.add(showTimeField);

        JLabel showDateLabel = new JLabel("Show Date (YYYY-MM-DD):");
        showDateLabel.setFont(new Font("Segoe UI", Font.BOLD, 22));
        showDateLabel.setForeground(Color.YELLOW);
        showDateLabel.setBackground(Color.BLACK);
        showDateLabel.setOpaque(true);
        showDateLabel.setBounds(200, 450, 300, 30);
        contentPane.add(showDateLabel);

        showDateField = new JTextField();
        showDateField.setFont(new Font("Segoe UI", Font.PLAIN, 20));
        showDateField.setBounds(550, 450, 400, 35);
        contentPane.add(showDateField);

        addButton = new JButton("Add Movie");
        addButton.setFont(new Font("Segoe UI", Font.BOLD, 24));
        addButton.setForeground(Color.RED);
        addButton.setBackground(Color.BLACK);
        addButton.setBounds(500, 510, 250, 70);
        contentPane.add(addButton);

        addButton.addActionListener(e -> addMovie());

        backButton = new JButton("Back");
        backButton.setFont(new Font("Segoe UI", Font.BOLD, 35));
        backButton.setForeground(Color.YELLOW);
        backButton.setBackground(Color.BLACK);
        backButton.setBounds(30, 40, 120, 50);
        contentPane.add(backButton);

        backButton.addActionListener(e -> {
            dispose();
            new AdminDashboard().setVisible(true);
        });

        setVisible(true);
    }

    private void addMovie() {
        String title = titleField.getText().trim();
        String duration = durationField.getText().trim();
        String genre = genreField.getText().trim();
        String industry = industryField.getText().trim();
        String releaseDate = releaseDateField.getText().trim();
        String showTime = showTimeField.getText().trim();
        String showDate = showDateField.getText().trim();

        if (title.isEmpty() || duration.isEmpty() || genre.isEmpty() || industry.isEmpty()
                || releaseDate.isEmpty() || showTime.isEmpty() || showDate.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill all fields.");
            return;
        }

        try (Connection conn = DBConnection.getConnection()) {
            PreparedStatement checkStmt = conn.prepareStatement(
                "select * from movies WHERE show_date = ? AND show_time = ?"
            );
            checkStmt.setDate(1, Date.valueOf(showDate));
            checkStmt.setTime(2, Time.valueOf(showTime));

            ResultSet checkRs = checkStmt.executeQuery();

            if (checkRs.next()) {
        
                JOptionPane.showMessageDialog(this, "A movie is already scheduled at this date and time.");
                checkRs.close();
                return;
            }

            checkRs.close();

            PreparedStatement stmt = conn.prepareStatement(
                "INSERT INTO movies (title, duration, genre, industry, release_date, show_time, show_date) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?)"
            );
            stmt.setString(1, title);
            stmt.setInt(2, Integer.parseInt(duration));
            stmt.setString(3, genre);
            stmt.setString(4, industry);
            stmt.setDate(5, Date.valueOf(releaseDate)); 
            stmt.setTime(6, Time.valueOf(showTime));  
            stmt.setDate(7, Date.valueOf(showDate));

            stmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "Movie added successfully.");
            clearFields();
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }


    private void clearFields() {
        titleField.setText("");
        durationField.setText("");
        genreField.setText("");
        industryField.setText("");
        releaseDateField.setText("");
        showTimeField.setText("");
        showDateField.setText("");
    }

    public static void main(String[] args) {
        new AddMovies().setVisible(true);;
    }
}

