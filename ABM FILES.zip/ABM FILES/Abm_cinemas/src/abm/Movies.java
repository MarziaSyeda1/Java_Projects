package abm;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.sql.*;

public class Movies extends JFrame {
    private Image backgroundImage;
    private JTable table;
    private JTextField searchField;
    private JButton searchButton, back;
    private JLabel search;
    private int userId;

    public Movies(int userId) {
        this.userId = userId;

        initializeMovies();
    }

    
   // public Movies() {
     //   this.userId = 1; 
       // initializeMovies();
    //}

    private void initializeMovies() {
        setTitle("Movies ShowTimes");
        setSize(1300, 738);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(true);

        try {
            backgroundImage = new ImageIcon(getClass().getResource("/images/background.png")).getImage();
        } catch (Exception e) {
            e.printStackTrace();
        }

        JPanel contentPane = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (backgroundImage != null) {
                    g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
                }
            }
        };
        contentPane.setLayout(null);
        setContentPane(contentPane);

        JLabel titleLabel = new JLabel("ABM CINEMAS", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Ravie", Font.BOLD, 80));
        titleLabel.setForeground(Color.YELLOW);
        titleLabel.setBounds(0, 25, 1300, 100);
        contentPane.add(titleLabel);

        search = new JLabel("Search movie by title:");
        search.setFont(new Font("Segoe UI", Font.BOLD, 20));
        search.setBounds(150, 140, 400, 35);
        search.setForeground(Color.YELLOW);
        search.setBackground(Color.BLACK);
        search.setOpaque(true);
        contentPane.add(search);

        searchField = new JTextField();
        searchField.setFont(new Font("Segoe UI", Font.PLAIN, 18));
        searchField.setBounds(400, 140, 400, 35);
        contentPane.add(searchField);

        searchButton = new JButton("Search");
        searchButton.setFont(new Font("Segoe UI", Font.BOLD, 18));
        searchButton.setBounds(820, 140, 120, 35);
        searchButton.setForeground(Color.RED);
        searchButton.setBackground(Color.BLACK);
        contentPane.add(searchButton);

        String[] columns = {"Title", "Duration", "Genre", "Industry", "Release Date", "Show date", "Show Time"};
        DefaultTableModel model = new DefaultTableModel(columns, 0);

        
        try {
            Connection conn = DBConnection.getConnection();
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM movies");

            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getString("title"),
                        rs.getInt("duration") + " mins",
                        rs.getString("genre"),
                        rs.getString("industry"),
                        rs.getString("release_date"),
                        rs.getString("Show_date"),
                        rs.getString("show_time"),
                });
            }

            rs.close();
            stmt.close();
            conn.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error loading data: " + e.getMessage());
        }

        table = new JTable(model);
        table.setFont(new Font("Verdana", Font.BOLD, 15));
        table.setRowHeight(60);
        table.setForeground(Color.RED);
        table.setBackground(Color.BLACK);

        JTableHeader header = table.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 18));
        header.setForeground(Color.YELLOW);
        header.setBackground(Color.BLACK);

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(100, 200, 1100, 450);
        scrollPane.setOpaque(false);
        scrollPane.getViewport().setOpaque(false);
        contentPane.add(scrollPane);

        back = new JButton("Back");
        back.setFont(new Font("Segoe UI", Font.BOLD, 30));
        back.setForeground(Color.YELLOW);
        back.setBackground(Color.BLACK);
        back.setBounds(30, 40, 120, 50);
        contentPane.add(back);

        back.addActionListener(e -> {
            dispose();
            new UserDashBoard(userId).setVisible(true);
        });

        searchButton.addActionListener(e -> {
            String searchText = searchField.getText().toLowerCase();
            if (searchText.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please enter a title to search.");
                return;
            }

            boolean found = false;
            for (int i = 0; i < table.getRowCount(); i++) {
                String title = table.getValueAt(i, 0).toString().toLowerCase();
                if (title.contains(searchText)) {
                    table.setRowSelectionInterval(i, i);
                    table.scrollRectToVisible(table.getCellRect(i, 0, true));
                    found = true;
                    break;
                }
            }

            if (!found) {
                JOptionPane.showMessageDialog(this, "No matching record found.");
            }
        });

        setVisible(true);
    }

    public static void main(String[] args) {

     new Movies(1).setVisible(true);  
    }
}




