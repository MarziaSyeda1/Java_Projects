package abm;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridBagLayout;
import java.awt.Image;
import javax.swing.*;
import java.sql.*;

public class UserLogin extends JFrame {
    private Image backgroundImage;
    private JLabel userIdLabel, passwordLabel;
    private JTextField userIdField;
    private JPasswordField passwordField;
    private JButton loginButton, backButton;

    public UserLogin() {
        setTitle("User Login");
        setSize(1300, 738);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(true);

        try {
            backgroundImage = new ImageIcon(getClass().getResource("/images/background.png")).getImage();
        } catch (Exception e) {
            e.printStackTrace();
        }

        JPanel contentPane = new JPanel(new GridBagLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (backgroundImage != null) {
                    g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
                }
            }
        };
        contentPane.setOpaque(false);
        setContentPane(contentPane);

        setLayout(null);

        JLabel title = new JLabel("ABM CINEMAS", SwingConstants.CENTER);
        title.setFont(new Font("Ravie", Font.BOLD, 100));
        title.setForeground(Color.YELLOW);
        title.setBounds(0, 50, 1300, 150);
        contentPane.add(title);

        userIdLabel = new JLabel("User ID:");
        userIdLabel.setFont(new Font("Segoe UI", Font.BOLD, 35));
        userIdLabel.setForeground(Color.CYAN);
        userIdLabel.setBackground(Color.BLACK);
        userIdLabel.setOpaque(true);
        userIdLabel.setBounds(400, 300, 135, 50);
        contentPane.add(userIdLabel);

        passwordLabel = new JLabel("Password:");
        passwordLabel.setFont(new Font("Segoe UI", Font.BOLD, 40));
        passwordLabel.setForeground(Color.CYAN);
        passwordLabel.setBackground(Color.BLACK);
        passwordLabel.setOpaque(true);
        passwordLabel.setBounds(400, 370, 195, 50);
        contentPane.add(passwordLabel);

        userIdField = new JTextField();
        userIdField.setFont(new Font("Segoe UI", Font.PLAIN, 25));
        userIdField.setBounds(620, 300, 300, 40);
        contentPane.add(userIdField);

        passwordField = new JPasswordField();
        passwordField.setFont(new Font("Segoe UI", Font.PLAIN, 25));
        passwordField.setBounds(620, 370, 300, 40);
        contentPane.add(passwordField);

        loginButton = new JButton("Log-in");
        loginButton.setFont(new Font("Segoe UI", Font.BOLD, 35));
        loginButton.setForeground(Color.RED);
        loginButton.setBounds(600, 450, 180, 90);
        contentPane.add(loginButton);

        backButton = new JButton("Back");
        backButton.setFont(new Font("Segoe UI", Font.BOLD, 30));
        backButton.setForeground(Color.YELLOW);
        backButton.setBackground(Color.BLACK);
        backButton.setBounds(100, 500, 100, 80);
        contentPane.add(backButton);

        backButton.addActionListener(e -> {
            dispose();
            new Welcome().setVisible(true);
        });

        loginButton.addActionListener(e -> {
            String userid = userIdField.getText().trim();
            String password = new String(passwordField.getPassword()).trim();

            try {
                Connection conn = DBConnection.getConnection();
                String query = "Select * from users where user_id = ? AND password = ? AND is_admin = 0";
                PreparedStatement stmt = conn.prepareStatement(query);
                stmt.setString(1, userid);
                stmt.setString(2, password);

                ResultSet rs = stmt.executeQuery();

                if (rs.next()) {
                    JOptionPane.showMessageDialog(null, "Welcome, " + rs.getString("first_name") + "!");
                    int userId = rs.getInt("user_id"); 
                    dispose();
                  new UserDashBoard(userId).setVisible(true); 
                } else {
                    JOptionPane.showMessageDialog(null, "Invalid User ID or Password!");
                }

                rs.close();
                stmt.close();
                conn.close();
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(null, "Database Error: " + ex.getMessage());
            }
        });
    }

    public static void main(String[] args) {
        new UserLogin().setVisible(true);
    }
}
