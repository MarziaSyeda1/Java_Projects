package abm;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class UserChoices extends JFrame {
    private Image backgroundImage;
    private JButton login, signUp, back;

    public UserChoices() {
        setTitle("User Choices");
        setSize(1300, 738);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(true);

        try {
            backgroundImage = new ImageIcon(getClass().getResource("/images/background.png")).getImage();
        } catch (Exception e) {
            e.printStackTrace();
        }

        JPanel contentPane = new JPanel(new GridBagLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (backgroundImage != null) {
                    g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
                }
            }
        };
        contentPane.setOpaque(false);
        setContentPane(contentPane);

        
        setLayout(null);
        JLabel title = new JLabel("ABM CINEMAS", SwingConstants.CENTER);
        title.setFont(new Font("Ravie", Font.BOLD, 100));
        title.setForeground(Color.YELLOW);
        title.setBounds(0, 50, 1300, 150);
        contentPane.add(title);
        
        JLabel askingLabel = new JLabel("Log-in or Sign-up (If not already registered)", SwingConstants.CENTER);
        askingLabel.setFont(new Font("Perpetua", Font.BOLD, 40));
        askingLabel.setForeground(Color.CYAN);
        askingLabel.setBackground(Color.BLACK);
        askingLabel.setBounds(200, 250, 900, 60); 
        askingLabel.setOpaque(true);
        contentPane.add(askingLabel);
     
 
        login = new JButton("Login");
        login.setFont(new Font("Segoe UI", Font.BOLD, 35));
        login.setForeground(Color.RED);
        login.setBounds(400, 350, 180, 100);
        contentPane.add(login);

        signUp = new JButton("SignUp");
        signUp.setFont(new Font("Segoe UI", Font.BOLD, 35));
        signUp.setForeground(Color.RED);
    
        signUp.setBounds(710, 350, 180, 100);
        contentPane.add(signUp);
        
        back = new JButton("Back");
        back.setFont(new Font("Segoe UI", Font.BOLD, 30));
        back.setForeground(Color.YELLOW);
        back.setBackground(Color.BLACK);
        back.setBounds(100, 500, 100, 80);
        contentPane.add(back);
        
        back.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	dispose();
            	new UserChoices().setVisible(true);}
            });
   
        login.addActionListener(e -> {
            dispose();
          new UserLogin().setVisible(true);
        });

        signUp.addActionListener(e -> {
            dispose();
            new UserSignUp().setVisible(true);
        });

        back.addActionListener(e -> {
            dispose();
            new Welcome().setVisible(true);
        });
    }

    public static void main(String[] args) {
       new UserChoices().setVisible(true);
    }
}

 
