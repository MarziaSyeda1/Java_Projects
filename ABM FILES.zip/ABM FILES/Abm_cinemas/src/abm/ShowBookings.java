package abm;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.sql.*;

public class ShowBookings extends JFrame {
    private JTable table;
    private Image backgroundImage;
    private int userId;
    private JButton back;

    public ShowBookings(int userId) {
        this.userId = userId;

        setTitle("ABM CINEMAS");
        setSize(1300, 738);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(true);

        try {
            backgroundImage = new ImageIcon(getClass().getResource("/images/background.png")).getImage();
        } catch (Exception e) {
            e.printStackTrace();
        }

        JPanel contentPane = new JPanel() {
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (backgroundImage != null) {
                    g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
                }
            }
        };
        contentPane.setLayout(null);
        setContentPane(contentPane);

        JLabel titleLabel = new JLabel("ABM CINEMAS", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Ravie", Font.BOLD, 80));
        titleLabel.setForeground(Color.YELLOW);
        titleLabel.setBounds(0, 25, 1300, 100);
        contentPane.add(titleLabel);

        String[] columns = {"Booking ID", "Movie Title", "Seat Number", "Show Time", "Show Date", "Seat Price", "Booking Time"};
        DefaultTableModel model = new DefaultTableModel(columns, 0);

        // Fetch booking data along with movie info and seat price
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                     "SELECT b.booking_id, m.title, b.seat_number, m.show_time, m.show_date, b.booking_date, s.price " +
                     "FROM bookings b " +
                     "JOIN movies m ON b.movie_id = m.movie_id " +
                     "JOIN seats s ON b.seat_number = s.seat_number " +
                     "WHERE b.user_id = ?")) {
            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getInt("booking_id"),
                        rs.getString("title"),
                        rs.getString("seat_number"),
                        rs.getString("show_time"),
                        rs.getString("show_date"),
                        "₹" + rs.getInt("price"),
                        rs.getTimestamp("booking_date").toString()
                });
            }

            rs.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error loading bookings: " + e.getMessage());
        }

        table = new JTable(model);
        table.setFont(new Font("Verdana", Font.BOLD, 15));
        table.setRowHeight(60);
        table.setForeground(Color.RED);
        table.setBackground(Color.BLACK);

        JTableHeader header = table.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 18));
        header.setForeground(Color.YELLOW);
        header.setBackground(Color.BLACK);

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(100, 200, 1100, 450);
        scrollPane.setOpaque(false);
        scrollPane.getViewport().setOpaque(false);
        contentPane.add(scrollPane);

        back = new JButton("Back");
        back.setFont(new Font("Segoe UI", Font.BOLD, 30));
        back.setForeground(Color.RED);
        back.setBackground(Color.BLACK);
        back.setBounds(30, 40, 120, 50);
        contentPane.add(back);

        back.addActionListener(e -> {
            dispose();
            new UserDashBoard(userId).setVisible(true);
        });

        setVisible(true);
    }

    public static void main(String[] args) {
        new ShowBookings(1).setVisible(true);
    }
}
