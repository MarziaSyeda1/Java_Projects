package abm;

import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class AdminCancelBooking extends JFrame {
    private JTextField bookingIdField;
    private JButton cancelButton, backButton;
    private Image backgroundImage;


    public AdminCancelBooking() {
     

        setTitle("ABM CINEMAS");
        setSize(1300, 738);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(true);

        try {
            backgroundImage = new ImageIcon(getClass().getResource("/images/background.png")).getImage();
        } catch (Exception e) {
            e.printStackTrace();
        }

        JPanel contentPane = new JPanel() {
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (backgroundImage != null) {
                    g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
                }
            }
        };
        contentPane.setLayout(null);
        setContentPane(contentPane);

        JLabel titleLabel = new JLabel("ABM CINEMAS", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Ravie", Font.BOLD, 60));
        titleLabel.setForeground(Color.YELLOW);
        titleLabel.setBounds(0, 25, 1300, 100);
        contentPane.add(titleLabel);

        JLabel bookingIdLabel = new JLabel("Enter Booking ID to Cancel:");
        bookingIdLabel.setFont(new Font("Segoe UI", Font.BOLD, 35));
        bookingIdLabel.setBounds(150, 200, 470, 50);
        bookingIdLabel.setForeground(Color.YELLOW);
        bookingIdLabel.setBackground(Color.BLACK);
        bookingIdLabel.setOpaque(true);
        contentPane.add(bookingIdLabel);

        bookingIdField = new JTextField();
        bookingIdField.setFont(new Font("Segoe UI", Font.PLAIN, 50));
        bookingIdField.setBounds(630, 200, 450, 45);
        contentPane.add(bookingIdField);

        cancelButton = new JButton("Cancel Booking");
        cancelButton.setFont(new Font("Segoe UI", Font.BOLD, 45));
        cancelButton.setBounds(500, 320, 390, 70);
        cancelButton.setForeground(Color.RED);
        cancelButton.setBackground(Color.BLACK);
        contentPane.add(cancelButton);

        cancelButton.addActionListener(e -> cancelBooking());

        backButton = new JButton("Back");
        backButton.setFont(new Font("Segoe UI", Font.BOLD, 30));
        backButton.setForeground(Color.YELLOW);
        backButton.setBackground(Color.BLACK);
        backButton.setBounds(30, 40, 120, 50);
        contentPane.add(backButton);

        backButton.addActionListener(e -> {
            dispose();
            new AdminDashboard().setVisible(true);
        });

        setVisible(true);
    }

    private void cancelBooking() {
        String input = bookingIdField.getText().trim();

        if (input.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter a booking ID.");
            return;
        }

        int bookingId;

        try {
            bookingId = Integer.parseInt(input);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Invalid booking ID.");
            return;
        }

        try (Connection conn = DBConnection.getConnection()) {
            conn.setAutoCommit(false);

            PreparedStatement fetch = conn.prepareStatement(
                "SELECT * FROM bookings WHERE booking_id = ?"
            );
            fetch.setInt(1, bookingId);
            ResultSet rs = fetch.executeQuery();

            if (!rs.next()) {
                JOptionPane.showMessageDialog(this, "No booking found for this ID.");
                return;
            }

            PreparedStatement delete = conn.prepareStatement(
                "DELETE FROM bookings WHERE booking_id = ?"
            );
            delete.setInt(1, bookingId);
            delete.executeUpdate();

            conn.commit();

            JOptionPane.showMessageDialog(this, "Booking cancelled successfully.");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error cancelling booking: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
   new AdminCancelBooking().setVisible(true);
    }
}
