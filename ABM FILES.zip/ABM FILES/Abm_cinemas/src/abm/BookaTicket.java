package abm;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class BookaTicket extends JFrame {
	private Image backgroundImage;
    private JComboBox<String> movieDropdown, seatDropdown;
    private JButton bookButton,backButton;
    private int userId;

    public BookaTicket(int userId) {
    	this.userId = userId;

        setTitle("User Dashboard");
        setSize(1300, 738);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(true);

        // Load background image
        try {
            backgroundImage = new ImageIcon(getClass().getResource("/images/background.png")).getImage();
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Custom panel with background image
        JPanel contentPane = new JPanel(new GridBagLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (backgroundImage != null) {
                    g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
                }
            }
        };
        contentPane.setOpaque(false);
        setContentPane(contentPane);
        setLayout(null);

        // Title Label
        JLabel title = new JLabel("ABM CINEMAS", SwingConstants.CENTER);
        title.setFont(new Font("Ravie", Font.BOLD, 100));
        title.setForeground(Color.YELLOW);
        title.setBounds(0, 50, 1300, 150);
        contentPane.add(title);

        JLabel movieLabel = new JLabel("Select Movie:");
        movieLabel.setFont(new Font("Segoe UI", Font.BOLD, 30));
        movieLabel.setForeground(Color.YELLOW);
        movieLabel.setBackground(Color.BLACK);
        movieLabel.setOpaque(true);
        movieLabel.setBounds(270, 180, 200, 60);
        contentPane.add(movieLabel);

        movieDropdown = new JComboBox<>();
        movieDropdown.setFont(new Font("Segoe UI", Font.BOLD, 25));
        movieDropdown.setBounds(500, 180, 500, 60);
        contentPane.add(movieDropdown);

        JLabel seatLabel = new JLabel("Select Seat:");
        seatLabel.setFont(new Font("Segoe UI", Font.BOLD, 30));
        seatLabel.setForeground(Color.YELLOW);
        seatLabel.setBackground(Color.BLACK);
        seatLabel.setOpaque(true);
        seatLabel.setBounds(270, 300, 200, 60);
        contentPane.add(seatLabel);

        seatDropdown = new JComboBox<>();
        seatDropdown.setBounds(500, 300, 500, 60);
        seatDropdown.setFont(new Font("Segoe UI", Font.BOLD, 30));
        contentPane.add(seatDropdown);

        bookButton = new JButton("Book Ticket");
        bookButton.setFont(new Font("Segoe UI", Font.BOLD, 44));
        bookButton.setForeground(Color.RED);
        bookButton.setBackground(Color.BLACK);
        bookButton.setBounds(500, 410, 300, 100);
        contentPane.add(bookButton);
        
        backButton = new JButton("Back");
        backButton.setFont(new Font("Segoe UI", Font.BOLD, 30));
        backButton.setBackground(Color.BLACK);
        backButton.setForeground(Color.RED);
        backButton.setBounds(270, 430, 180, 60);
        contentPane.add(backButton);
        
        loadMovies();
        movieDropdown.addActionListener(e -> loadAvailableSeats());
        bookButton.addActionListener(e -> bookTicket());
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                new UserDashBoard(userId).setVisible(true);
            }
        });
    }

    private void loadMovies() {
        movieDropdown.removeAllItems();
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT movie_id, title, show_time, show_date FROM movies")) {
            while (rs.next()) {
                int id = rs.getInt("movie_id");
                String movieInfo = id + " - " + rs.getString("title") + " - " +
                                   rs.getString("show_time") + " - " + rs.getString("show_date");
                movieDropdown.addItem(movieInfo);
            }
        } catch (SQLException e) {
            showError("Could not load movies.");
        }
    }

    private void loadAvailableSeats() {
        seatDropdown.removeAllItems();
        String selectedMovie = (String) movieDropdown.getSelectedItem();
        if (selectedMovie == null) return;

        int movieId = Integer.parseInt(selectedMovie.split(" - ")[0]);

        String query = "select seat_number FROM seats WHERE seat_number NOT IN " +
                       "(select seat_number FROM bookings WHERE movie_id = ?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, movieId);
            try (ResultSet rs = stmt.executeQuery()) {
                boolean found = false;
                while (rs.next()) {
                    seatDropdown.addItem(rs.getString("seat_number"));
                    found = true;
                }
                if (!found) {
                    seatDropdown.addItem("No seats available");
                    seatDropdown.setEnabled(false);
                } else {
                    seatDropdown.setEnabled(true);
                }
            }
        } catch (SQLException e) {
            showError("Could not load available seats.");
        }
    }

    private void bookTicket() {
        String movieItem = (String) movieDropdown.getSelectedItem();
        String seat = (String) seatDropdown.getSelectedItem();

        if (movieItem == null || seat == null || seat.equals("No seats available")) {
            showError("Please select both a movie and a seat.");
            return;
        }

        int movieId = Integer.parseInt(movieItem.split(" - ")[0]);

        try (Connection conn = DBConnection.getConnection()) {

            int price = 0;
            PreparedStatement priceStmt = conn.prepareStatement("SELECT price FROM seats WHERE seat_number = ?");
            priceStmt.setString(1, seat);
            ResultSet priceRs = priceStmt.executeQuery();
            if (priceRs.next()) {
                price = priceRs.getInt("price");
            } else {
                showError("Seat price not found.");
                return;
            }

            PreparedStatement insert = conn.prepareStatement(
                "INSERT INTO bookings (user_id, movie_id, seat_number, booking_date) " +
                "VALUES (?, ?, ?, CURRENT_TIMESTAMP)"
            );
            insert.setInt(1, userId);
            insert.setInt(2, movieId);
            insert.setString(3, seat);
       ;

            insert.executeUpdate();

            JOptionPane.showMessageDialog(this, "Ticket booked for seat: " + seat + " | Price: Rs." + price);
            loadAvailableSeats();

        } catch (SQLException e) {
            showError("Booking failed: " + e.getMessage());
        }
    }


    private void showError(String msg) {
        JOptionPane.showMessageDialog(this, msg);
    }

    public static void main(String[] args) {
        new BookaTicket(1).setVisible(true);
    }
}