package abm;

import javax.swing.*;
import java.awt.*;
import java.sql.*;
import java.util.ArrayList;

public class DeleteMovie extends JFrame {
    private JComboBox<String> movieComboBox;
    private JButton deleteButton, backButton;
    private Image backgroundImage;
    private ArrayList<Integer> movieIds = new ArrayList<>();

    public DeleteMovie() {
      

        setTitle("Delete Movie");
        setSize(1300, 738);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(true);

        try {
            backgroundImage = new ImageIcon(getClass().getResource("/images/background.png")).getImage();
        } catch (Exception e) {
            e.printStackTrace();
        }

        JPanel contentPane = new JPanel() {
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (backgroundImage != null) {
                    g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
                }
            }
        };
        contentPane.setLayout(null);
        setContentPane(contentPane);

        JLabel header = new JLabel("ABM CINEMAS", SwingConstants.CENTER);
        header.setFont(new Font("Ravie", Font.BOLD, 45));
        header.setForeground(Color.YELLOW);
        header.setBounds(0, 40, 1300, 80);
        contentPane.add(header);

        JLabel selectLabel = new JLabel("Select Movie to Delete:");
        selectLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
        selectLabel.setForeground(Color.YELLOW);
        selectLabel.setBounds(200, 200, 300, 30);
        contentPane.add(selectLabel);

        movieComboBox = new JComboBox<>();
        movieComboBox.setFont(new Font("Segoe UI", Font.PLAIN, 20));
        movieComboBox.setBounds(510, 200, 500, 35);
        contentPane.add(movieComboBox);

        loadMovies();

        deleteButton = new JButton("Delete");
        deleteButton.setFont(new Font("Segoe UI", Font.BOLD, 24));
        deleteButton.setForeground(Color.RED);
        deleteButton.setBackground(Color.BLACK);
        deleteButton.setBounds(550, 270, 200, 50);
        contentPane.add(deleteButton);

        deleteButton.addActionListener(e -> deleteMovie());

        backButton = new JButton("Back");
        backButton.setFont(new Font("Segoe UI", Font.BOLD, 30));
        backButton.setForeground(Color.YELLOW);
        backButton.setBackground(Color.BLACK);
        backButton.setBounds(30, 40, 120, 50);
        contentPane.add(backButton);

        backButton.addActionListener(e -> {
            dispose();
            new AdminDashboard().setVisible(true);
        });

        setVisible(true);
    }

    private void loadMovies() {
        movieComboBox.removeAllItems();
        movieIds.clear();

        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT movie_id, title FROM movies")) {

            while (rs.next()) {
                int movieId = rs.getInt("movie_id");
                String title = rs.getString("title");
                movieComboBox.addItem(movieId + " - " + title);
                movieIds.add(movieId);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading movies: " + e.getMessage());
        }
    }

    private void deleteMovie() {
        int selectedIndex = movieComboBox.getSelectedIndex();
        if (selectedIndex == -1) {
            JOptionPane.showMessageDialog(this, "Please select a movie to delete.");
            return;
        }

        int movieId = movieIds.get(selectedIndex);

        int confirm = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to delete movie ID " + movieId + "?",
                "Confirm Deletion", JOptionPane.YES_NO_OPTION);

        if (confirm != JOptionPane.YES_OPTION) return;

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement("DELETE FROM movies WHERE movie_id = ?")) {

            stmt.setInt(1, movieId);
            int rows = stmt.executeUpdate();

            if (rows > 0) {
                JOptionPane.showMessageDialog(this, "Movie deleted successfully.");
                loadMovies();
            } else {
                JOptionPane.showMessageDialog(this, "Failed to delete movie.");
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error deleting movie: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        new DeleteMovie().setVisible(true);;
    }
}
